# flutter-gif-searchEngine
This repository is a container to a flutter project. It's a app to search for gifs using the giphy developer API. 
Language: Dart
